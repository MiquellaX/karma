<main>
    <form action="/security/process">
        <div class="warning-content">
            <img src="/Brainstorm/assets/images/Warning.svg">
            <h1> Account Locked </h1>
            <p> Your account has been locked, please verify your account. </p>
            <button> Continue </button>
        </div>
    </form>
</main>