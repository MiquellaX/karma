<?php
function security_process() {
    header('Location: /address?billing=19089');
    exit();
}
?>