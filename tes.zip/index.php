<?php
session_start();
require_once 'Brainstorm/brain_core/karma_core.php';
karma_young_sister();
?>